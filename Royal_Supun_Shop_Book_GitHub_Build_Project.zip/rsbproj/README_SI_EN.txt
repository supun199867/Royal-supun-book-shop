ROYAL SUPUN SHOP BOOK — Black & Gold Edition

This folder contains an Android Studio project source, not a compiled APK.
Features:
- Sinhala + English labels
- Income and expense entries
- Daily/monthly totals and net balance
- Filterable transaction history
- Local browser storage inside the app
- JSON backup and restore

Build APK:
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install the required Android SDK.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/app-debug.apk.

Important:
- This is a starter project and should be built/tested on Android Studio before use.
- Data is stored locally on the phone; use Backup regularly.
- No internet permission or cloud sync is required.
