package com.royalsupun.shopbook;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.view.Window;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setStatusBarColor(Color.rgb(16,16,16));
  getWindow().setNavigationBarColor(Color.rgb(16,16,16));
  WebView w = new WebView(this);
  w.setBackgroundColor(Color.rgb(16,16,16));
  WebSettings s = w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  w.setWebViewClient(new WebViewClient());
  w.setWebChromeClient(new WebChromeClient());
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}